package com.jaidev.seeaplayer.dataClass

data class Folder(val id : String,val folderName: String)