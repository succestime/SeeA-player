package com.jaidev.seeaplayer.dataClass

class IconModel(var imageView: Int, var iconTitle: String, val iconTint: Int = android.R.color.white) {

}
