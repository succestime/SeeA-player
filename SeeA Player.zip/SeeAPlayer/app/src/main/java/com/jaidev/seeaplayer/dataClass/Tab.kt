package com.jaidev.seeaplayer.dataClass

import androidx.fragment.app.Fragment

data class Tab(var name: String, val fragment: Fragment)
